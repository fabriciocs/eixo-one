# Execução operacional — FG-021 Metas e forecast comercial

**Slug:** `fg-021-metas-e-forecast-comercial`  
**Módulo:** CRM e Comercial  
**Prioridade:** Média  
**Complexidade:** Média  
**Status origem:** Backlog  
**Branch sugerida:** `feature/fg-021-metas-e-forecast-comercial`  
**Data:** 2026-04-27

## 1. Definição e Produto

### Objetivo
Implementar a funcionalidade **Metas e forecast comercial** no módulo **CRM e Comercial**.

### Contexto
Controla metas por vendedor, equipe, produto ou período, comparando realizado, pipeline e previsão.

### Problema de negócio
A gestão precisa acompanhar performance comercial e antecipar desvios de receita.

### MVP
Definir metas; acompanhar realizado; calcular forecast; comparar períodos; alertar desvios; painel por vendedor/equipe.

### Requisitos não funcionais
Cálculos consistentes; atualização em tempo real ou near-real-time; relatórios rápidos; controle de acesso.

### Integrações impactadas
Oportunidades; pedidos; BI

### LGPD
Aplicável: **Não**.  
Aplicar minimização, rastreabilidade, controle de acesso, logs sem dados pessoais sensíveis e retenção conforme política aprovada.

### Campos e regras extraídos da planilha
Campos comuns obrigatórios/recomendados:
- id (UUID/ULID): gerado no backend, obrigatório e imutável.
- tenantId (UUID): obrigatório pelo contexto autenticado; bloquear acesso entre tenants.
- empresaId (UUID): validar empresa ativa e permissão do usuário.
- filialId (UUID): obrigatório quando a operação exigir filial; validar vínculo com empresa.
- codigo (string): único por tenant/empresa/filial quando aplicável; 2-30 caracteres.
- nome/titulo (string): obrigatório; 2-150 caracteres; sem HTML/script.
- descricao/observacao (text): opcional; limitar tamanho; sanitizar/escapar na saída.
- status (enum): validar transições por máquina de estados.
- createdAt/createdBy (audit): gerado no servidor.
- updatedAt/updatedBy (audit): gerado no servidor.
- version/etag (integer/string): controle de concorrência otimista.
- deletedAt/deletedBy (audit): soft delete quando houver histórico/dependências.

Campos específicos da funcionalidade:
- periodo (month/quarter/year): sem sobreposição no escopo.
- vendedor/equipe (UUID): escopo obrigatório.
- valorMeta (money/number): >0.
- indicador (enum): receita/margem/oportunidades.
- forecast (money): calculado.
- formula (json/DSL): segura e versionada.
- meta (number/money/percent): valor alvo.
- periodicidade (enum): dia/semana/mês.
- alertas (json): limiares/canais.

Validações e regras:
- meta aprovada exige revisão.
- forecast pondera oportunidades.
- fórmula reprodutível.
- metas sem sobreposição.
- validar no frontend para UX e repetir no backend como fonte de verdade.
- normalizar entrada antes de validar e rejeitar campos inesperados.
- usar allowlist de tipos, tamanhos, enums, formatos, faixas e relações permitidas.
- escapar saída em telas, PDF, XLSX e relatórios para prevenir XSS.
- autorizar por ação, recurso, tenant, empresa, filial, escopo e proprietário.
- registrar auditoria com actorId, tenantId, empresaId, filialId, ação, before/after/diff, IP, userAgent e correlationId.
- usar transações/idempotência em operações críticas.
- implementar paginação, filtros server-side, índices e limites de payload.
- mascarar dados pessoais, financeiros, fiscais e segredos em logs e telas.
- cobrir regras com testes unitários, integração/API, frontend e autorização.

## 2. UX/UI e Arquitetura

### Jornada
1. Usuário acessa o módulo **CRM e Comercial**.
2. Visualiza lista com busca, filtros, status e ações permitidas por RBAC.
3. Cria/edita registro em formulário com validações inline.
4. Sistema valida no backend, registra auditoria e aplica isolamento por tenant/empresa/filial.
5. Usuário acompanha histórico, erros, pendências e integrações.

### Telas e componentes
- Listagem responsiva.
- Formulário de cadastro/edição.
- Filtros por status, empresa, filial, período e responsável quando aplicável.
- Estado vazio, carregando, erro, sem permissão e conflito de versão.
- Painel de auditoria.
- Ações de ativar, inativar, bloquear, cancelar ou concluir conforme máquina de estados.

### Arquitetura técnica
- Backend TypeScript Node/Nest-like.
- Controller fino.
- Service com regras de negócio.
- Repository/DAO substituível por ORM real.
- DTOs com validação server-side.
- PostgreSQL como referência.
- Frontend React ou Flutter conforme app alvo.
- OpenAPI para contratos.
- Auditoria com `createdAt`, `createdBy`, `updatedAt`, `updatedBy`, `version`, `deletedAt`.

### Segurança
- `tenantId`, `empresaId`, `filialId` e `actorId` sempre vindos do contexto autenticado.
- RBAC por ação: criar, ler, editar, aprovar, cancelar, excluir, exportar.
- Soft delete quando houver histórico ou integração.
- Logs sem payload bruto sensível.
- Idempotência em endpoints integrados.

## 3. QA e Relatório

### Estratégia de testes
- Unitários para validações e regras de estado.
- Integração para repository/service.
- E2E para fluxo principal.
- Teste de isolamento multiempresa/multifilial.
- Teste de autorização RBAC.
- Teste de auditoria.
- Teste de regressão para integrações: Oportunidades; pedidos; BI.

### Critérios de aceite
- CRUD ou fluxo principal implementado conforme MVP.
- Validação server-side bloqueia dados inválidos.
- Busca e filtros funcionam com paginação.
- Auditoria criada em todas as alterações.
- Usuário sem permissão não acessa dados ou ações.
- Dados de outro tenant/empresa não aparecem.
- Erros são rastreáveis e amigáveis.
- Testes automatizados críticos passam.

### Evidências esperadas
- `npm run lint --if-present`
- `npm run typecheck --if-present`
- `npm run test --if-present`
- `npm run build --if-present`
- `flutter test` quando houver impacto mobile.

## 4. Arquivos a gerar/aplicar

```text
codigo-fonte/backend/src/modules/fg-021-metas-e-forecast-comercial/
codigo-fonte/frontend/src/features/fg-021-metas-e-forecast-comercial/
codigo-fonte/database/migrations/20260427_fg_021_fg-021-metas-e-forecast-comercial.sql
codigo-fonte/contracts/openapi/fg-021-metas-e-forecast-comercial.openapi.yaml
codigo-fonte/tests/fg-021-metas-e-forecast-comercial.spec.ts
codigo-fonte/docs/01-definicao-produto.md
codigo-fonte/docs/02-ux-arquitetura.md
codigo-fonte/docs/03-qa-relatorio.md
```

## 5. Comandos GitHub Actions

<!-- actions-exec:run -->
```bash
set -euo pipefail

slug="fg-021-metas-e-forecast-comercial"

git fetch origin main
git checkout main
git pull --ff-only origin main
git checkout -B "feature/${slug}"

mkdir -p "docs/${slug}"

cat > "docs/${slug}/README.md" <<'DOC'
# FG-021 — Metas e forecast comercial

Entrega baseada nas planilhas de requisitos e UX/UI.

Módulo: CRM e Comercial

Resumo:
Controla metas por vendedor, equipe, produto ou período, comparando realizado, pipeline e previsão.
DOC

npm install
npm run lint --if-present
npm run typecheck --if-present
npm run test --if-present
npm run build --if-present

git status --short
git add "docs/${slug}/README.md"
git commit -m "feat(crm-e-comercial): implementa FG-021 Metas e forecast comercial" || echo "Sem alterações para commit"
git push -u origin "feature/${slug}"
```

## 6. Riscos e pendências
- Ajustar imports/providers ao framework real do repositório.
- Confirmar regras fiscais/financeiras quando aplicável.
- Validar retenção LGPD com jurídico.
- Validar integrações reais antes de ativar em produção.
- Revisar permissões por perfil.
