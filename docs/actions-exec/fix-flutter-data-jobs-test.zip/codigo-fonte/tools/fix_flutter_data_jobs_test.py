#!/usr/bin/env python3
from pathlib import Path
import re
import sys

TEST_PATH = Path("apps/mobile_flutter/test/features/governance/governance_pages_test.dart")

HELPER = r"""
Future<void> pumpGovernanceDataJobsUntilStable(WidgetTester tester) async {
  // CI can render this page with a smaller viewport and delayed provider updates.
  // Keep the helper intentionally generic so it does not mask real assertion errors.
  await tester.pump();
  for (var i = 0; i < 6; i += 1) {
    await tester.pump(const Duration(milliseconds: 100));
  }
  await tester.pumpAndSettle(const Duration(milliseconds: 250));
}

Future<void> revealGovernanceDataJobsContent(WidgetTester tester) async {
  final scrollables = find.byType(Scrollable);
  if (scrollables.evaluate().isEmpty) {
    return;
  }

  // Do one bounded drag to materialize lazily built content without depending on
  // localized labels or implementation-specific widget keys.
  await tester.drag(scrollables.first, const Offset(0, -360));
  await tester.pumpAndSettle(const Duration(milliseconds: 250));
}
"""

def insert_helper(source: str) -> str:
    if "pumpGovernanceDataJobsUntilStable" in source:
        return source

    # Insert after last import.
    matches = list(re.finditer(r"^import .+?;\s*$", source, flags=re.MULTILINE))
    if not matches:
        raise SystemExit("Nenhum import encontrado no arquivo de teste.")
    pos = matches[-1].end()
    return source[:pos] + "\n" + HELPER + source[pos:]

def patch_failing_test(source: str) -> str:
    test_name = "data jobs page loads seeded jobs and workspace"
    idx = source.find(test_name)
    if idx < 0:
        raise SystemExit(f"Teste não encontrado: {test_name}")

    # Find the opening body close enough after the test name.
    body_start = source.find("{", idx)
    if body_start < 0:
        raise SystemExit("Não foi possível localizar início do corpo do teste.")

    # Insert immediately after the first pumpAndSettle/pumpWidget section if not already inserted.
    marker = "await pumpGovernanceDataJobsUntilStable(tester);"
    block_end = source.find("});", body_start)
    if block_end < 0:
        raise SystemExit("Não foi possível localizar fim do teste.")
    block = source[body_start:block_end]

    if marker in block:
        return source

    insert_after_patterns = [
        r"await tester\.pumpAndSettle\([^;]*\);\s*",
        r"await tester\.pump\([^;]*\);\s*",
    ]

    for pattern in insert_after_patterns:
        match = re.search(pattern, block)
        if match:
            absolute = body_start + match.end()
            insertion = (
                "\n      await pumpGovernanceDataJobsUntilStable(tester);"
                "\n      await revealGovernanceDataJobsContent(tester);\n"
            )
            return source[:absolute] + insertion + source[absolute:]

    # Fallback: insert right after body starts.
    absolute = body_start + 1
    insertion = (
        "\n      await pumpGovernanceDataJobsUntilStable(tester);"
        "\n      await revealGovernanceDataJobsContent(tester);\n"
    )
    return source[:absolute] + insertion + source[absolute:]

def main() -> int:
    if not TEST_PATH.exists():
        raise SystemExit(f"Arquivo não encontrado: {TEST_PATH}")

    original = TEST_PATH.read_text(encoding="utf-8")
    patched = insert_helper(original)
    patched = patch_failing_test(patched)

    if patched == original:
        print("Nenhuma alteração necessária.")
        return 0

    backup = TEST_PATH.with_suffix(TEST_PATH.suffix + ".bak-actions-exec")
    backup.write_text(original, encoding="utf-8")
    TEST_PATH.write_text(patched, encoding="utf-8")
    print(f"Patch aplicado em {TEST_PATH}")
    print(f"Backup criado em {backup}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
