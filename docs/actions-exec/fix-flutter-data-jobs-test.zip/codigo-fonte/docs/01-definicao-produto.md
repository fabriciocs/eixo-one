# Documento 01 — Definição e Produto

## Objetivo
Corrigir a falha de CI no `flutter test`:

`data jobs page loads seeded jobs and workspace`

## Contexto
O log informado mostra 14 testes aprovados e 1 teste falhando em:
`apps/mobile_flutter/test/features/governance/governance_pages_test.dart`.

O log não contém o bloco completo `Expected/Actual`, então a correção foi estruturada como patch seguro e reversível para estabilizar o teste de Data Jobs em ambiente CI, sem alterar regras de negócio.

## Escopo
- Reexecutar teste com saída expandida.
- Aplicar helper de estabilização de pumps.
- Aplicar scroll bounded para materializar conteúdo lazy em viewport reduzido.
- Reexecutar `flutter test`.
- Gerar evidências em `docs/actions-exec/fix-flutter-data-jobs-test/`.

## Fora de escopo
- Alterar regras de negócio de governança.
- Desabilitar ou pular teste.
- Usar delays arbitrários longos.
