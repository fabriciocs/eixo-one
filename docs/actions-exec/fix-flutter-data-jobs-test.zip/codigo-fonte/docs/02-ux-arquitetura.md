# Documento 02 — UX e Arquitetura

## Diagnóstico técnico
A falha ocorre em teste de widget Flutter para página de Data Jobs. Esse tipo de falha costuma ocorrer quando:
- provider assíncrono ainda não estabilizou;
- conteúdo está em área scrollável/lazy e não foi materializado;
- viewport do CI difere do ambiente local.

## Correção aplicada pelo pacote
- Helper `pumpGovernanceDataJobsUntilStable`.
- Helper `revealGovernanceDataJobsContent`.
- Patch apenas no teste específico `data jobs page loads seeded jobs and workspace`.
- Sem skip, sem alteração de expectativa e sem ocultar assertion real.

## Segurança
- Patch cria backup `.bak-actions-exec`.
- Usa caminhos fixos dentro do repositório.
- Não apaga arquivos.
- Não altera dados sensíveis.
