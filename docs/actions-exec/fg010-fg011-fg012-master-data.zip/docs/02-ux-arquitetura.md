# 02 — UX e Arquitetura: FG-010, FG-011, FG-012

## Jornada
O usuário acessa Cadastros Mestres, escolhe Clientes, Fornecedores ou Produtos, pesquisa registros, aplica filtros por empresa, filial e status, abre detalhe em abas e executa criação ou edição com validação inline.

## Telas e componentes
Página de listagem com busca, filtros, cards responsivos, chips de status, loading, empty state, erro com retry e ações contextuais.

Formulário em seções: dados principais, fiscal, comercial, financeiro, contatos, endereços, anexos, histórico e auditoria.

## Acessibilidade
Campos têm labels, supporting text, mensagens por campo, foco visível, alvos mínimos de toque e estados comunicados por texto.

## Arquitetura
Backend: módulo master-data com domain, validators, repository, service e controller.

Frontend: página reutilizável MasterDataPage para clientes, fornecedores e produtos.

Banco: tabela master_data_records com payload JSONB para evolução segura e índices de busca. Auditoria append-only em audit_events.

## APIs sugeridas
GET /customers
POST /customers
GET /suppliers
POST /suppliers
GET /products
POST /products
PATCH /master-data/:id
POST /master-data/:id/block
DELETE /master-data/:id

## Autenticação e autorização
O contexto autenticado injeta tenantId, empresaId, filialId, actorId, roles, permissions e correlationId.

Permissões:
master-data.read
master-data.customer.create
master-data.customer.update
master-data.customer.block
master-data.supplier.create
master-data.supplier.update
master-data.product.create
master-data.product.update

## Segurança e LGPD
Minimização de dados, consentimentos para clientes, mascaramento em logs, auditoria estruturada, soft delete, autorização por objeto e segregação tenant/empresa/filial.

## Plano técnico
Aplicar arquivos do pacote ao repositório real, mapear o repositório concreto, substituir repositório in-memory por ORM/Firestore existente, conectar controller às rotas reais e executar migrações e testes.
