# 01 — Definição e Produto: FG-010, FG-011, FG-012

## Objetivo
Implementar e padronizar Cadastros Mestres para clientes, fornecedores e produtos com isolamento por tenant, empresa e filial.

## Contexto e problema
As planilhas indicam prioridade alta para os três cadastros. Eles sustentam vendas, compras, financeiro, estoque, fiscal, CRM e relatórios. Dados incorretos nesses mestres geram faturamento errado, pagamentos indevidos, divergências fiscais e falhas de estoque.

## Escopo MVP
FG-010 Cadastro de clientes: PF/PJ, CPF/CNPJ, IE/IM, contatos, endereços, limite de crédito, vendedor, tags, consentimentos, bloqueios e histórico auditável.

FG-011 Cadastro de fornecedores: dados fiscais, bancários, homologação, documentos, categorias, risco, avaliação, prazo médio, bloqueios e histórico auditável.

FG-012 Cadastro de produtos: SKU, código de barras, descrição, categoria, unidade, preço, custo, NCM, CEST, estoque mínimo, lote, validade, imagens e produto composto.

## Requisitos
Os registros devem ter id, tenantId, empresaId, filialId quando aplicável, código único, nome, status, auditoria, versionamento e soft delete.

As APIs devem implementar paginação, filtros, busca, validação server-side, autorização deny-by-default e auditoria.

## Regras
CPF/CNPJ, NCM, CEST, e-mail, código de barras, preço, custo, status e transições são validados no backend.

Dados bancários, documentos pessoais e segredos são mascarados em logs e auditoria.

Operações críticas exigem permissão específica e registram before/after.

## Perfis
Administrador, analista comercial, financeiro, compras, estoque, fiscal e auditor.

## Critérios de aceite
Usuário autorizado cria, lista e atualiza cadastros.

Usuário sem permissão recebe 403 e não vê ações indevidas.

Duplicidade por tenant, empresa, filial, tipo e código é bloqueada.

Dados inválidos não geram gravação parcial.

Exclusão é lógica e bloqueada quando o registro ativo deve ser inativado primeiro.

## Riscos e pendências
Validar regras fiscais oficiais vigentes para NCM, CEST e inscrições estaduais.

Adaptar nomes de pastas, rotas e injeção de dependências ao repositório real após acesso ao GitHub.
